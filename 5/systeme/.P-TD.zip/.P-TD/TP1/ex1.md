#  Exercice 1

1. Un programme exécuté par un processeur

2.  * Instruction : (instruction à exécuter par le processeur une par une)

    * Environnement : (Variable global, pid, etc)

    * Mémoire : (pile, tas, donnée, code)

3. Oui car ils ne trournent pas sur le processeurs (ils sont en attentes)

4. Oui (c'est bien un programme qui tourne sur un processeur)
