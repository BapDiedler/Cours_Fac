#  Exercie 3

1. 2 -> 4 -> 8 -> 16

2. Il va effasser le processus à l'infinie et se recréé lui même

3. Il va créé une infitée de processus