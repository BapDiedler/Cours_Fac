/*
1. Quelle est la définition d’un processus ?
    Le processus est un programme exécuté par un processeur.

2. De quoi se compose un processus ? Expliquez.
    Le processus est composé de 3 choses:
        les instructions : une partie de programme
        un environement : les variables d'environement ou descripteur de fichier
        la mémoire : pile et tas

3. Peut-on avoir plusieurs processus prêts dans le système ?
    Oui on peut avoir plusieurs processus prêts dans le système mais un seul est réellement entrain de tourner

4. Le système d’exploitation est-il un processus ?
    Oui l'OS est un processus créé au départ.
*/
