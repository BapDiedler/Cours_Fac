package calculette;

interface Expression {
	public int valeur();
	public String toString();
}
