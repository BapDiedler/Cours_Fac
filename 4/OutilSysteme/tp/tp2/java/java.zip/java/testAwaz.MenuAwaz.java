package testAwaz;

import awaz.Awaz;
import awaz.AwazImage;
/**
 * Cette classe est le point de d�part du Tp Awaz
 * @author martine
 * @version Janvier 2018
 */
public class MenuAwaz {
    public static void main(String[] args) {
        System.out.println("Bonjour");
    }
}
