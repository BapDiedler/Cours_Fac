package reseau.tests;

import reseau.Message;

public class TestMessage {

        public static void main(String[] args) {

        // A faire ...
    }

}
