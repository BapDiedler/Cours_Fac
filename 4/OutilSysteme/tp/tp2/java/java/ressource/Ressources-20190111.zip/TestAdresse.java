package reseau.tests;

import reseau.adresses.Adresse;

public class TestAdresse {
    public static void main(String[] args) {
        testGetNbreOctetsAdresse() ;
        // A compléter
    }

    private static void testGetNbreOctetsAdresse() {
        Adresse a ;
        int res ;

        // adresse créée vide
        a = new Adresse(16) ;
        res = a.getNbreOctets() ;
        assert(res==2):"Nombre d'octets incorrect" ;

        // adresse définie
        a = new Adresse("192.45.43.100");
        res = a.getNbreOctets() ;
        assert  (res==4):"Nombre d'octets incorrect" ;
    }
}
