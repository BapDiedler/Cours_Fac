package testAwaz;

import awaz.Awaz;

/**
 * Cette classe est le point de d�part du Tp Awaz
 * @author martine
 * @version Janvier 2018
 */
public class MainAwaz {
    public static void main(String[] args) {
        // Cr�ation d'une m�lodie vide
        Awaz melodie = new Awaz() ;

        // A compl�ter ...
        //  ...


    }
}
