package arithmetique ;

/**
 * Addition de plusieurs opérandes
 */
public class Addition {

    private int[][] operandes ;         // Un opérande par ligne ; un chiffre de l'opérande par colonne
    public int [] resultat ;            // un chiffre de résultat par case

    /** Créer une addition sans opérande
     */
    public Addition() {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /** Créer une addition avec des opérandes pris au hasard
     * @param nbOper nombre d'opérandes
     * @param nbChif nombre de chiffres de chaque opérande
     * @exception AssertionError si nbOper < 1 ou nbChif < 1
     */
    public Addition(int nbOper, int nbChif) {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /** Fixer les opérandes
     * @param operandes opérandes
     * @exception AssertionError si operandes.length <= 1 ou si tous les opérandes n'ont pas la même longueur
     */
    public void fixerOperandes(int[]... operandes) {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /** Fixer les opérandes au hasard
     * @param nbOper nombre d'opérandes
     * @param nbChif nombre de chiffres de chaque opérande
     * @exception AssertionError si nbOper < 1 ou nbChif < 1
     */
    public void fixerOperandes(int nbOper, int nbChif) {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /**
     * Additionne les opérandes, pour former le résultat
     */
    private void calculer() {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /** Consulter un chiffre d'un opérande
     * @param oper numéro de l'opérande
     * @param rang rang du chiffre
     * @return le chiffre de numéro rang, dans l'opérande oper
     */
    public int getChiffre(int oper, int rang) {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /**
     * @return Nombre d'opérandes
     * @exception AssertionError si estVide()
     */
    public int nbOperandes() {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /**
     * @return Nombre de chiffres
     * @exception AssertionError si estVide()
     */
    public int nbChiffres() {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /**
     * @return vrai l'addition est vide (sans opérande)
     */
    public boolean estVide() {
        return true ;
    }

    /**
     * @return une chaîne avec tous les opérandes
     */
    public String toString() {
        throw new RuntimeException("Fonction indéfinie") ;
    }

    /** Le chiffre suggéré est-il correct par rapport à la solution ?
     * @param chiffre chiffre suggéré
     * @param rang rang où on voudrait le placer
     * @return vrai si le chiffre est le même dans la solution
     * @exception AssertionError si chiffre < 0 ou chiffre > 9 ou rang < 0 ou rang >= nbChiffres()
     */
    public boolean chiffreCorrect(int chiffre, int rang) {
        throw new RuntimeException("Fonction indéfinie") ;
    }
}

