#ifndef RESSOURCE_H
#define RESSOURCE_H

//plateau
int WIDTH;//taille max 100
int HEIGHT; //taille max 100
int PLATEAU[100][100];

//pion
int X;
int Y;
#endif