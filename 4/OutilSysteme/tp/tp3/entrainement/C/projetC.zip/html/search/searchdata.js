var indexSectionsWithContent =
{
  0: "acdj",
  1: "aj",
  2: "cd"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

