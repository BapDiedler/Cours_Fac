var searchData=
[
  ['creation_5fjeu_8',['creation_jeu',['../jouer_8h.html#a0c7a5f03bc249c53687e37bbb16e04e5',1,'jouer.c']]],
  ['creation_5fplateau_9',['creation_plateau',['../affichage_8h.html#abf5fcf044b545dae32bbd699fb1b57bc',1,'affichage.c']]]
];
