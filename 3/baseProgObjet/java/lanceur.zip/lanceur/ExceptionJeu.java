public class ExceptionJeu extends Exception {
    public ExceptionJeu(String mes){
        super(mes);
    }
}
